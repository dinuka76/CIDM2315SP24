namespace Homework1;
class Program
{
    static void Main(string[ ] args)
    {
       {
            double x = 2.5;
            double y = 3.3;
            double z = 4 * x * x + 3 * y; 
            Console.WriteLine(z); 
        }
    }
    }
